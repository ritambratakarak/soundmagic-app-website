
$(document).ready(function(){

    $('#categorySlider').owlCarousel({
    loop:true,
    margin:20,
    nav:true,
    dots:false,
    autoplay: false,
    responsiveClass:true,
    responsive:{
        0:{
            items:1
           
        },
        600:{
            items:2
            
        },
        1000:{
            items:4
        } 
    }
});
    
      $('#courseSlider').owlCarousel({
    loop:true,
    margin:30,
    nav:true,
    dots:false,
    autoplay: false,
    responsiveClass:true,
    responsive:{
        0:{
            items:1
           
        },
        600:{
            items:2
            
        },
        1000:{
            items:4
        } 
    }
});
    
      $('#featureSlider').owlCarousel({
    loop:true,
    margin:30,
    nav:true,
    dots:false,
    autoplay: false,
    responsiveClass:true,
    responsive:{
        0:{
            items:1
           
        },
        600:{
            items:1
            
        },
        1000:{
            items:3
        } 
    }
});
    
    
    
    
    
    });